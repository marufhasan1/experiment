<?php
$config["site_title"]="Maruf hasan";

$config["units"]=array('PCS','KG','Dojon');