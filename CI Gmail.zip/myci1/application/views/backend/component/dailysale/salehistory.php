                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>Find Sale</h4>
                             </div>
                             <div class="panel-body">
                              <?php
                                    $attr=array(
                                          'class'=>'form-horizontal'
                                    );
                              echo form_open('',$attr);?>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Voucher No<span class="req">&nbsp;</span></label>
                                          <div class="col-md-6">
                                              <input type="text" name="v_no[voucher_no]" class="form-control"/>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Date<span class="req">&nbsp;</span></label>
                                          <div class="col-md-3">
                                              <input type="text" name="date_from[sale_date]" class="form-control" placeholder="From"/>
                                          </div>
                                          <div class="col-md-3">
                                              <input type="text" name="date_to[sale_date]" class="form-control" placeholder="To"/>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <div class="col-md-6 col-sm-offset-2">
                                                <input class="btn btn-primary" name="view_sale" type="submit" value="Show">       
                                          </div>
                                    </div>
                              <?php echo form_close(); ?>
                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php //if($all_purchases!=null){?>
                         <div class="panel panel-custom">
                         <!--pre><?php print_r($all_sale);?></pre-->
                             <div class="panel-heading">
                                <h4>All Sale</h4>
                             </div>
                             <div class="panel-body">
                              <table class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Voucher Number</th>
                                  <th>Date</th>
                                  <th>Action</th>
                                </tr>
                                <?php  foreach ($all_sale as $key => $sale) { ?>
                                <tr>
                                  <td><?php echo $key+1; ?></td>
                                  <td><?php echo $sale->voucher_no; ?></td>
                                  <td><?php echo $sale->sale_date; ?></td>
                                  <td>
                                    <a href="<?php echo base_url('backend/dailysale/payslip_dayli/'.$sale->voucher_no); ?>" class="btn btn-primary">View</a>
                                    <a onclick="return(strong_confirmation())" href="" class="btn btn-danger" >Delete</a>
                                  </td>
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php// } ?>
                    </div>
                  </div>
            </div>
        </section>