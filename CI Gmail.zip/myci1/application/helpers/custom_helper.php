<?php
	function filter($value){
		$value=ucwords(str_replace('_',' ',$value));
		return $value;
	}

	function skip_space($value){
		$value=ucwords(str_replace(' ','_',$value));
		return $value;
	}

	function exist_validation($var,$field){
		if ($var!=null) {
			# code...
		}
	}