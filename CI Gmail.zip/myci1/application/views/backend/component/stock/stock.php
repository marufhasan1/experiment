                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>Filter Product</h4>
                             </div>
                             <div class="panel-body">
                              <?php
                                    $attr=array(
                                          'class'=>'form-horizontal'
                                    );
                              echo form_open('',$attr);?>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Product ID<span class="req">&nbsp;</span></label>
                                          <div class="col-md-6">
                                              <input type="text" name="field[stock_product_id]" class="form-control"/>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Quantity Less Then<span class="req">&nbsp;</span></label>
                                          <div class="col-md-6">
                                              <input type="text" name="field[stock_quantity]" class="form-control"/>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <div class="col-md-6 col-sm-offset-2">
                                                <input class="btn btn-primary" name="view_stock" type="submit" value="Show">       
                                          </div>
                                    </div>
                              <?php echo form_close(); ?>
                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php //if($all_purchases!=null){?>
                         <div class="panel panel-custom">
                         <!--pre><?php print_r($all_purchases);?></pre-->
                             <div class="panel-heading">
                                <h4>Stock</h4>
                             </div>
                             <div class="panel-body">
                              <table class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Product ID</th>
                                  <th>Product Name</th>
                                  <th>Stock Quantity</th>
                                  <!--th>Action</th-->
                                </tr>
                                <?php foreach ($all_stock as $key => $stock) {
                                  $where=array('product_id'=>$stock->stock_product_id);
                                  $product_info=$this->db_action->read('products',$where);
                                  //print_r($product_info);
                                ?>
                                <tr>
                                  <td><?php echo $key+1; ?></td>
                                  <td><?php echo $stock->stock_product_id; ?></td>
                                  <td><?php echo $stock->stock_product_name; ?></td>
                                  <td><?php echo $stock->stock_quantity; ?></td>
                                  <!--td>
                                    <a href="<?php echo base_url('backend/product/edit_product');?>?id=<?php echo $stock->id; ?>" class="btn btn-primary">View</a>
                                    <a onclick="return(strong_confirmation())" href="?delete_token=<?php// echo $product->id; ?>" class="btn btn-danger" >Delete</a>
                                  </td-->
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php // } ?>
                    </div>
                  </div>
            </div>
        </section>