<?php
class Profile extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	public function index(){
		$this->info['page_title']='Create Profile';
		$this->info['active']='createprofile';
		$img_url="";

		if ($this->input->post('add_user')){

			$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|xss_clean|is_unique[users.username]');
        	$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]|xss_clean');
            $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');

        	if ($this->form_validation->run()==TRUE) {
        		$data=array(
        			'name'		=>	$this->input->post('name'),
        			'birth_date'=>	$this->input->post('birth_date'),
        			'username'	=>	$this->input->post('username'),
        			'password'	=>	$this->hash($this->input->post('password')),
        			'privilege'	=>	$this->input->post('privilege'),
        			'mobile'	=>	$this->input->post('mobile'),
        			'email'		=>	$this->input->post('email')
        		);
        		//File Upload Start here
        		if ($_FILES['image']['name']!=null && $_FILES['image']['name']!="") {
        			$src=$_FILES['image']['tmp_name'];
        			$destination='private/upload/users/users_'.rand(10000,99999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
        			if (copy($src,$destination)) {
        				$data['image']=$destination;
        			}
        		}
        		//File Upload End here
        		$msg_array=array(
						'title'=>"Success",
						'message'=>"New User Successfully Saved"
						);

				$this->session->set_flashdata('confirm', message($this->db_action->add("users", $data),$msg_array));
            } else{
                    $msg_array=array(
                    'title'=>"Success",
                    'message'=>validation_errors()
                    );

                $this->session->set_flashdata('confirm', message("warning",$msg_array));
            }
			header("location: ".base_url('access/profile'));

		}

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/user/create_profile',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

    public function all_profile(){
        $this->info['page_title']='All Profile';
        $this->info['active']='';
        $this->info['confirmation']=null;
        $img_url="";

        $this->info['all_profile']=$this->db_action->read('users');

        $this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
        $this->load->view('backend/user/all_profile',$this->info);
        $this->load->view('backend/include/footer',$this->info);
    }

    public function view_profile($username=null){
        $this->info['page_title']='All Profile';
        $this->info['active']='';
        $this->info['confirmation']=null;
        $where=array(
            "username"=>$username
        );

        $this->info['profile_info'] = $this->db_action->read("users",$where);

        $this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
        $this->load->view('backend/user/view_profile',$this->info);
        $this->load->view('backend/include/footer',$this->info);
    }

    public function edit_profile($id=null){
        $this->info['page_title']='All Profile';
        $this->info['active']='';
        $this->info['confirmation']=null;
        $where=array("id"=>$id);

        if ($this->input->post('add_user')){

            $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|xss_clean');
            $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean');

            if ($this->form_validation->run()==TRUE) {
                $data=array(
                    'name'      =>  $this->input->post('name'),
                    'birth_date'=>  $this->input->post('birth_date'),
                    'username'  =>  $this->input->post('username'),
                    'privilege' =>  $this->input->post('privilege'),
                    'mobile'    =>  $this->input->post('mobile'),
                    'email'     =>  $this->input->post('email')
                );
                //File Upload Start here
                if ($_FILES['image']['name']!=null && $_FILES['image']['name']!="") {
                    $src=$_FILES['image']['tmp_name'];
                    $destination='private/upload/users/users_'.rand(10000,99999).'.'.pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);
                    if (copy($src,$destination)) {
                        if (is_file("./".$this->input->post('old_image'))) {
                            unlink("./".$this->input->post('old_image'));
                        }
                        $data['image']=$destination;
                    }
                }
                //File Upload End here
                $msg_array=array(
                        'title'=>"Success",
                        'message'=>"New User Successfully Updated"
                        );

                $this->session->set_flashdata('confirm', message($this->db_action->update("users", $data, $where),$msg_array));
            } else{
                    $msg_array=array(
                    'title'=>"Success",
                    'message'=>validation_errors()
                    );

                $this->session->set_flashdata('confirm', message("warning",$msg_array));
            }
            header("location: ".base_url('access/profile/edit_profile/'.$id));

        }

        $this->info['profile_info'] = $this->db_action->read("users",$where);

        $this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
        $this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
        $this->load->view('backend/user/edit_profile',$this->info);
        $this->load->view('backend/include/footer',$this->info);
    }
    public function delete_profile($id=null){

        $where=array("id"=>$id);
        $profile_info = $this->db_action->read("users",$where);
        if (is_file("./".$profile_info[0]->image)) {
            unlink("./".$profile_info[0]->image);
        }
        $msg_array=array(
        'title'=>"Success",
        'message'=>"Delete Success Fully"
        );

        
        $this->session->set_flashdata('confirm', message($this->db_action->delete("users",$where),$msg_array));
        redirect('access/profile/all_profile','refresh');
    }

	    public function hash($string) {
        return hash('md5', $string . config_item('encryption_key'));
    }

}