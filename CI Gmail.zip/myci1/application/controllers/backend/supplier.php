<?php
class Supplier extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Supplier';
		$this->info['active']='supplier';
		$this->info['sub_active']='add-supplier';
		$this->info['confirmation']=null;
		if ($this->input->post('add_supplier')) {

			$this->form_validation->set_rules('company_name','Company Name','trim|required|xss_clean|is_unique[supplier.company_name]');
			$this->form_validation->set_rules('supplier_name','Supplier Name','trim|required|xss_clean');
			//$this->form_validation->set_rules('supplier_mobile','Supplier Mobile','trim|required|xss_clean|is_unique[supplier.supplier_mobile]');
			//$this->form_validation->set_rules('supplier_email','Supplier Email','trim|required|xss_clean|valid_email|is_unique[supplier.supplier_email]');
			$this->form_validation->set_rules('supplier_id','Supplier ID','trim|required|xss_clean|is_unique[supplier.supplier_id]');
			if ($this->form_validation->run() == FALSE) {
				$msg_array=array(
				'title'=>"Warinng",
				'message'=>validation_errors()
				);

			$this->session->set_flashdata('confirm', message('warning',$msg_array));
			header("location: ".base_url('/backend/supplier'));
			}else{
			$data=array(
				"company_name"=>	$this->input->post("company_name"),
				"supplier_name"=>	$this->input->post("supplier_name"),
				"supplier_mobile"=>	$this->input->post("supplier_mobile"),
				"supplier_email"=>	$this->input->post("supplier_email"),
				"supplier_id"=>		$this->input->post("supplier_id"),
				"supplier_address"=>$this->input->post("supplier_address"),
				"supplier_note"=>	$this->input->post("supplier_note"),
				"date"=>			date("Y-m-d")
				);

			$msg_array=array(
				'title'=>"Success",
				'message'=>"Data Successfully Saved"
				);

			$this->session->set_flashdata('confirm', message($this->db_action->add("supplier", $data),$msg_array));
			//$this->info['confirmation']=$this->session->flashdata('confirm');

			header("location: ".base_url('/backend/supplier'));
		}
	}

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/supplier/supplier-nav',$this->info);
		$this->load->view('backend/component/supplier/supplier',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

//-----------------------------------------------------------------------------------------------
//------------------------------------All Supplier Start here------------------------------------
//-----------------------------------------------------------------------------------------------
	function all_supplier(){
		$this->info['page_title']='Supplier';
		$this->info['active']='supplier';
		$this->info['sub_active']='view-supplier';
		$this->info['confirmation']=null;

		//--------------------------------------------------------------
		//------------------Delete Data Start here----------------------
		//--------------------------------------------------------------
		if ($this->input->get('delete_token')){
			$where=array(
				'id'=>$this->input->get('delete_token')
				);
			$this->db_action->delete('supplier',$where);
			redirect(base_url('backend/supplier/all_supplier?delete=1'));
			
		}

		$msg_array=array(
			'title'=>"Success",
			'message'=>"Data Successfully Deleted"
		);
		if ($this->input->get('delete')&&$this->input->get('delete')==1) {
			$this->info['confirmation']=message('danger',$msg_array);
		}

		//--------------------------------------------------------------
		//------------------Delete Data End here------------------------
		//--------------------------------------------------------------



		$this->info['suppliers']=$this->db_action->read('supplier');
		
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/supplier/supplier-nav',$this->info);
		$this->load->view('backend/component/supplier/all-supplier',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
//-----------------------------------------------------------------------------------------------
//-------------------------------------All Supplier End here-------------------------------------
//-----------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//------------------------------------View Supplier Start here------------------------------------
//------------------------------------------------------------------------------------------------
	function view_supplier(){
		$this->info['page_title']='Supplier';
		$this->info['active']='supplier';
		$this->info['sub_active']='';
		$this->info['confirmation']=null;

		$where=array(
			'id'=>$this->input->get('id')
			);

		$this->info['suppliers']=$this->db_action->read('supplier',$where);
		
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/supplier/supplier-nav',$this->info);
		$this->load->view('backend/component/supplier/view-supplier',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
//------------------------------------------------------------------------------------------------
//-------------------------------------View Supplier End here-------------------------------------
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------
//------------------------------------Edit Supplier Start here------------------------------------
//------------------------------------------------------------------------------------------------
	function edit_supplier(){
		$this->info['page_title']='Supplier';
		$this->info['active']='supplier';
		$this->info['sub_active']='';
		$this->info['confirmation']=null;

		$where=array(
			'id'=>$this->input->get('id')
			);

		if ($this->input->post('update_supplier')) {
			$data=array(
				"company_name"=>	$this->input->post("company_name"),
				"supplier_name"=>	$this->input->post("supplier_name"),
				"supplier_mobile"=>	$this->input->post("supplier_mobile"),
				"supplier_email"=>	$this->input->post("supplier_email"),
				"supplier_id"=>		$this->input->post("supplier_id"),
				"supplier_address"=>$this->input->post("supplier_address"),
				"supplier_note"=>	$this->input->post("supplier_note"),
				"date"=>			date("Y-m-d")
				);

			$msg_array=array(
				'title'=>"Success",
				'message'=>"Data Successfully Updated"
				);

			//$this->info['confirmation']=message($this->db_action->update("supplier", $data,$where),$msg_array);
			$this->session->set_flashdata('confirm', message($this->db_action->update("supplier", $data,$where),$msg_array));
			header("location: ".base_url('/backend/supplier/edit_supplier?id='.$this->input->get('id')));
		}

		$this->info['suppliers']=$this->db_action->read('supplier',$where);
		
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/supplier/supplier-nav',$this->info);
		$this->load->view('backend/component/supplier/edit-supplier',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
//------------------------------------------------------------------------------------------------
//-------------------------------------Edit Supplier End here-------------------------------------
//------------------------------------------------------------------------------------------------

}