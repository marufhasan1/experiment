<?php

namespace r\ProtocolBuffer;

class ResponseResponseNote
{
    const PB_ATOM_FEED            = 2;
    const PB_INCLUDES_STATES      = 5;
    const PB_ORDER_BY_LIMIT_FEED  = 3;
    const PB_SEQUENCE_FEED        = 1;
    const PB_UNIONED_FEED         = 4;
}
