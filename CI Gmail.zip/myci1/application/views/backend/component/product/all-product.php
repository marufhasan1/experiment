                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>Filter Product</h4>
                             </div>
                             <div class="panel-body">
                              <?php
                                    $attr=array(
                                          'class'=>'form-horizontal'
                                    );
                              echo form_open('',$attr);?>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Company Name <span class="req">*</span></label>
                                          <div class="col-md-6">
                                              <select required name="company_name" id="" class="form-control">
                                                <option value="">--Select Company Name--</option>
                                                <?php foreach ($suppliers as $key => $supplier) { ?>
                                                <option value="<?php echo $supplier->company_name?>"><?php echo $supplier->company_name?></option>
                                                <?php } ?>
                                              </select>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <div class="col-md-6 col-sm-offset-2">
                                                <input class="btn btn-primary" name="view_product" type="submit" value="Show">       
                                          </div>
                                    </div>
                              <?php echo form_close(); ?>
                             </div>
                             <div class="panel-footer"></div>
                         </div>

                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4 style="line-height:30px;">All Product</h4>
                                <span class="pull-right"><input class="form-control" type="text" placeholder="Search here...." id="search"> </span>
                             </div>
                             <div class="panel-body">
                              <?php 
                                //print_r($suppliers);
                              ?>

                              <table id="table" class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Company Name</th>
                                  <th>Product Name</th>
                                  <th>Brand</th>
                                  <th>Product ID</th>
                                  <th>Unit</th>
                                  <th>Action</th>
                                </tr>
                                <?php foreach ($products as $key => $product) { ?>
                                <tr class="tb_row">
                                  <td><?php echo $key+1; ?></td>
                                  <td><?php echo $product->company_name; ?></td>
                                  <td><?php echo $product->product_name; ?></td>
                                  <td><?php echo $product->product_brand; ?></td>
                                  <td><?php echo $product->product_id; ?></td>
                                  <td><?php echo $product->product_unit; ?></td>
                                  <td>
                                    <a href="<?php echo base_url('backend/product/edit_product');?>?id=<?php echo $product->id; ?>" class="btn btn-primary">Edit</a>
                                    <a onclick="return(strong_confirmation())" href="?delete_token=<?php echo $product->id; ?>" class="btn btn-danger" >Delete</a>
                                  </td>
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script type="text/javascript">
          var $rows = $('#table .tb_row');
          $('#search').keyup(function(){
            
            var val = '^(?=.*\\b' + $.trim($(this).val()).split(/\s+/).join('\\b)(?=.*\\b') + ').*$',
              reg = RegExp(val, 'i'),
              text;
            
            $rows.show().filter(function() {
              text = $(this).text().replace(/\s+/g, ' ');
              return !reg.test(text);
            }).hide();
          });
        </script>
