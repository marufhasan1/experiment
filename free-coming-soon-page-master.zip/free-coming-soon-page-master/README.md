
#Free Coming Soon Page HTML Template 
created by https://comingsoonpage.com

Get your free download at https://www.seedprod.com/free-coming-soon-page/

View Demo https://seedprod.github.io/free-coming-soon-page/

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License
http://creativecommons.org/licenses/by-nc-nd/4.0/

=================================================

To get started follow this checklist:

	1. Replace the *Page Title* on lines 23, 31 & 296
	2. Set the *Page Description* on lines 26, 32 & 298
	3. Set an optional *Logo* on lines 294 using the src attribute.
	4. Set your *Facebook Profile* URL on line 312 using the href attribute.
	5. Set your *Twitter Profile* URL on line 313 using the href attribute.
	6. Set your *Email* on line 314 using the href attribute.
	7. Set your background image on line 63, see file README.mb for additional background images.
	8. Set your MailChimp email post URL on line 300 See video: https://youtu.be/YUdP1qfMot8
	9. FTP to your Website. 

Pre selected background images values:
* Wave: https://images.unsplash.com/photo-1449168013943-3a15804bb41c?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=1958d4bfb59a246c6092ff0daabd284b
* Wood: https://images.unsplash.com/32/Mc8kW4x9Q3aRR3RkP5Im_IMG_4417.jpg?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=46a85a1451e47aea5152ade8299f2894
* Mountain: https://images.unsplash.com/34/BA1yLjNnQCI1yisIZGEi_2013-07-16_1922_IMG_9873.jpg?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=bb861c990a141e90c492fe79f7ff4307
* Sunset: https://images.unsplash.com/uploads/1412276054206cd55c23b/e04e888a?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=f847427a77aaeb2f779366fc80446628
* Ballons: https://images.unsplash.com/reserve/L55hYy77SLqb6zeTMlWr_IMG_9035.jpg?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=be8f13a3ec5d152f60ede73809372c97
* Bridge: https://images.unsplash.com/photo-1449034446853-66c86144b0ad?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=1080&fit=max&s=4a065bd135cef62a0425f00234a43b08

###### Background Images are from http://unsplash.com and are license under Creative Commons 0 (Public Domain)
