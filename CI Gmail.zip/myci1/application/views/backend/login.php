		<!--div class="preload"></div-->
		<section class="container-fluid form-container col-xs-12">
			<div class="row form-wrapper">
					<?php
						$attr=array('class'=>'login-form form-horizontal');
						echo form_open('',$attr);
					?>
						<div class="form-border">
							<div class="lock-border">
								<div class="lock">
									<i class="fa fa-lock"></i>
								</div>
							</div>

							<div class="l-form-group no-border">
								<p><?php echo $warning; ?></p>
							</div>

							<div class="l-form-group">
								<label class="l-control-label" for="username"><i class="fa fa-user"></i></label>
								<div class="input-holder">
									<input type="username" class="l-form-control" id="username" name="username" placeholder="Username" required >
								</div>
							</div>

							<div class="l-form-group">
								<label class="l-control-label" for="password"><i class="fa fa-key"></i></label>
								<div class="input-holder">
									<input type="password" class="l-form-control" id="password" name="password" placeholder="Password" required>
								</div>
							</div>

							<div class="l-form-group no-border">
								<label class="l-text" >Remember Me</label>
								<input type="checkbox" id="remember_me" name="remember_me" value="remember_true"/>
								<div class="slide-btn">
									<span id="remember_me_trigger"></span>
								</div>
							</div>
							<div class="l-form-group">
								<input type="submit" name="login" class="btn col-xs-12" value="Login"/>
							</div>
							<div class="l-form-group no-border">
								<a class="l-text" href="<?php echo base_url(); ?>">Go back home</a>
								<a class="r-text" href="#">Forget Password?</a>
							</div>
						</div>
					<?php echo form_close();?>
			</div>
		</section>

		<script>
			$(document).ready(function(){
			    $("#remember_me_trigger").on("click",function(){
			    	if ($("#remember_me").attr('checked')==null) {
				    	$(this).animate({left:'25px'});
				    	$(this).parent().css({background:'#749927'});
				    	$("#remember_me").attr('checked','checked');
				    }
				    else{
				    	$(this).animate({left:'0'});
				    	$(this).parent().css({background:'#F44D26'});
				    	$("#remember_me").removeAttr('checked');
				    }
			    });  
			});  
		</script>