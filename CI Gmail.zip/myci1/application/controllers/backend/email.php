<?php
class Email extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->load->library('email');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Product';
		$this->info['active']='product';
		$this->info['sub_active']='add-product';
		$this->info['confirmation']=null;

		//$config['mailpath'] = '/usr/sbin/sendmail';
		//$config['charset'] = 'iso-8859-1';

		$config['useragent'] = 'CodeIgniter';
		$config['protocol'] = 'smtp';
		//$config['mailpath'] = '/usr/sbin/sendmail';
		$config['smtp_host'] = 'ssl://smtp.googlemail.com';
		$config['smtp_user'] = 'emarufhasan@gmail.com';
		$config['smtp_pass'] = 'a01735189237';
		$config['smtp_port'] = 465; 
		$config['smtp_timeout'] = 5;
		$config['wordwrap'] = TRUE;
		$config['wrapchars'] = 76;
		$config['mailtype'] = 'html';
		$config['charset'] = 'utf-8';
		$config['validate'] = FALSE;
		$config['priority'] = 3;
		$config['crlf'] = "\r\n";
		$config['newline'] = "\r\n";
		$config['bcc_batch_mode'] = FALSE;
		$config['bcc_batch_size'] = 200;

		$this->email->initialize($config);


		$this->load->library('email'); // Note: no $config param needed
		$this->email->from('noreplay@gmail.com', 'Maruf Hasan Test');
		$this->email->to('emarufhasan2@gmail.com');
		$this->email->subject('Test email from CI and Gmail');
		$this->email->message('This is a test Message.');
		//$this->email->send();

		if (!$this->email->send())
		{
		   echo $this->email->print_debugger(array('headers'));
		}else{
			echo "Success";
		}

		//$this->email->cc('another@another-example.com');
		//$this->email->bcc('them@their-example.com');


		// $this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		// $this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		// $this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		// $this->load->view('backend/component/product/product-nav',$this->info);
		// $this->load->view('backend/component/product/product',$this->info);
		// $this->load->view('backend/include/footer',$this->info);
	}

}