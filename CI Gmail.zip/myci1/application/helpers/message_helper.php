<?php
	function message($type,$info=array()){
/*Types are
success
warning
danger
*/
		if (count($info)<1) {
			$info=array(
				'title'=>'Success',
				'message'=>'Your Action Successfully Done'
			);
		}


		$message='<div class="msg_body '.$type.'">
					<span class="msg-close"><i class="fa fa-times"></i></span>
					<h2>'.$info['title'].'</h2>
					<p>'.$info['message'].'</p>
				</div>';
		return $message;
	}