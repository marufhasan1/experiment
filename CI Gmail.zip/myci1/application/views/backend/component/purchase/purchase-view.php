                      <style>
                        table tr th{
                          background: #F5F5F5;
                        }

                        .pay-title{
                          text-align: right;
                          border-top: 2px solid #999;
                          font-weight: bold;
                        }
                        .summary{
                          background: #ddd;
                          padding: 0 5px;
                          line-height: 30px;
                          font-weight: bold;
                        }

                        .banner_print{
                          display: none;
                        }

                        @media print {
                          aside,header,.panel-heading,.page-nav{
                            display:  none;
                          }
                          .content-body{
                            margin: 0;
                            border: 0;
                          }
                          .main-content{
                            border: 0;
                            margin: 0;
                          }
                          .body{
                            padding: 0;
                          }
                          .banner_print{
                          display: block;
                          width: 100%;
                          }
                          table.details tr td,
                          table.details tr th,
                          table.details thead tr
                          {
                            border: 1px solid #eee;
                          }
                          table.details{
                            margin-top: 5px;
                          }
                        }
                      </style>                        
                         <div class="panel panel-custom">
                         <?php $purchase_product=json_decode($purchase_data[0]->purchase_data,true) ?>
                         <!--pre><?php print_r($purchase_product);?></pre-->
                               <div class="panel-heading">
                                  <h4>Purchase Informatioin</h4>
                                  <span id="print" title="Print"><i class="fa fa-print" aria-hidden="true"></i></span>
                               </div>
                               <div class="panel-body">
                                  <img class="banner_print" src="<?php echo base_url('private/asset/img/banner.png'); ?>" alt=""/>
                                  <p class="pay-title">Purchase Informatioin</p>
                                  <table class="table">
                                    <tr>
                                      <th>Date: </th>
                                      <td><?php echo $purchase_data[0]->date; ?></td>
                                    </tr>
                                    <tr>
                                      <th>Voucher No: </th>
                                      <td><?php echo $purchase_data[0]->voucher_number; ?></td>
                                    </tr>
                                    <tr>
                                      <th>Company Name: </th>
                                      <td><?php echo $purchase_data[0]->company_name; ?></td>
                                    </tr>
                                  </table>
                                  <p class="summary">Summary</p>
                                  <table class="table details">
                                    <thead>
                                      <tr>
                                        <th>SL</th>
                                        <th>Product Name</th>
                                        <th>Product ID</th>
                                        <th>Quantity</th>
                                        <th>Purchase Price</th>
                                        <th>Sale Price</th>
                                        <th>Expire date</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                      $total=0;
                                      foreach ($purchase_product as $data_key=>$per_data) {
                                      $where=array('product_id'=>$per_data["purchase_product_id"]);
                                      $product_info=$this->db_action->read('products',$where);
                                    ?>
                                      <tr>
                                        <td><?php echo $data_key+1; ?></td>
                                        <td><?php echo $product_info[0]->product_name; ?></td>
                                        <td><?php echo $per_data["purchase_product_id"]; ?></td>
                                        <td><?php echo $per_data["purchase_quantity"]; ?></td>
                                        <td><?php echo $per_data["purchase_price"]; ?></td>
                                        <td><?php echo $subtotal = $per_data["purchase_sale_price"] ?></td>
                                        <td><?php echo $per_data["purchase_exp_date"] ?></td>
                                      </tr>
                                    <?php
                                      $total+=$subtotal;
                                     } ?>
                                    <tr>
                                        <th colspan="6" >Total</th>
                                        <td><?php echo $total; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Inword</th>
                                        <td colspan="6"><span id="inword"></span></td>
                                    </tr>
                                    </tbody>
                                  </table>
                               </div>

                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script src="<?php echo base_url('private/asset/js/plugins/inwordbn.js');?>"></script>
        
        <script>
        $(document).ready(function(){
            $('#inword').html(inWordbn(<?php echo $total; ?>)+' টাকা মাত্র');
        });
        </script>
