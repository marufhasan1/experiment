		<!--______________________All Script Start Here______________________-->
		<script type="text/javascript" src="<?php echo base_url('private/asset/js/script.js') ;?>"></script>
		<!--______________________All Script End Here______________________-->
	</body>
</html>