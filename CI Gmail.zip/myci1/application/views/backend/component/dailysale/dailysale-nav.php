                        <div class="page-nav">
                              <a href="<?php echo base_url('backend/dailysale');?>" id="daily_sale">Daily Sale</a>
                              <a href="<?php echo base_url('backend/dailysale/sale_history');?>" id="salehistory">Sale History</a>
                        </div>