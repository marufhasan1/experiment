<?php
class Dailysale extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Dailysale';
		$this->info['active']='dailysale';
		$this->info['sub_active']='daily_sale';
		$this->info['confirmation']=null;
		//Generating Voucher Number start here
		$all_voucher=$this->db_action->read('daily_sale',array(),'id','desc');
		$current_voucher=0;
		if (count($all_voucher)>=1) {
			$current_voucher=$all_voucher[0]->id;
		}
		$next_voucher=str_pad($current_voucher+1,4,0,STR_PAD_LEFT);
		//echo $next_voucher;
		$this->info['voucher_no']=$voucher_no=date('Ymd').$next_voucher;
		//Generating Voucher Number end here

		if ($this->input->post('sale_product')) {
			$product_id=$this->input->post('product_id');
			$quantity=$this->input->post('quantity');
			$sale_price=$this->input->post('sale_price');


			foreach ($product_id as $ID_key => $productID) {
				//Getting Product name start here
				$product_info=$this->db_action->read("products",array("product_id"=>$productID));
				$product_name=$product_info[0]->product_name;
				//Getting Product Name end here

				$data=array(
					'sale_date'		 	=>date('Y-m-d'),
					'voucher_no'	 	=>$voucher_no,
					'sale_product_id'	=>$productID,
					'sale_product_name'	=>$product_name,
					'quantity'	 		=>$quantity[$ID_key],
					'sale_price'	 	=>$sale_price[$ID_key]
				);
				$stock_where=array('stock_product_id'=>$productID);
				$stock_data=$this->db_action->read('stock',$stock_where);
				$current_quantity=$stock_data[0]->stock_quantity;
				$new_quantity=$current_quantity-$quantity[$ID_key];
				$this->db_action->update('stock',array('stock_quantity'=>$new_quantity),$stock_where);
				$msg_array=array(
						'title'=>"Success",
						'message'=>"Data Successfully Saved"
						);

				$this->session->set_flashdata('confirm', message($this->db_action->add("daily_sale", $data),$msg_array));
				header("location: ".base_url('/backend/dailysale'));
				header("location: ".base_url('/backend/dailysale/payslip_dayli/'.$voucher_no));
			}
			//print_r($product_id);
		}

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/dailysale/dailysale-nav',$this->info);
		$this->load->view('backend/component/dailysale/dailysale',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

	function ajax_get_productInfo(){
		$product_id=$this->input->post('pid');
		$product=$this->db_action->sale_product($product_id);
		//$product_info=json_encode($product);

      if (count($product)>0) {
        $dom='<tr class="per_item '.$product[0]->stock_product_id.'">
        <td><input readonly value="'.$product[0]->product_name.'" tabindex="3" autocomplete="off" required type="text" name="purchase_product_name[]" placeholder="Product Name" class="form-control"/></td>
        <td><input readonly value="'.$product[0]->stock_product_id.'" type="text" name="product_id[]" placeholder="Product ID" class="form-control product_id"/></td>
        <td><input value="1" tabindex="3" required type="number" min="0" max="'.$product[0]->stock_quantity.'" title="'.$product[0]->stock_quantity.'" name="quantity[]" placeholder="Quantity" class="form-control quantity"/></td>
        <td><input readonly value="'.$product[0]->product_unit.'"readonly type="text" placeholder="Unit" class="form-control unit"/></td>
        <td><input value="'.$product[0]->sale_price.'" tabindex="3" required type="number" name="sale_price[]" placeholder="Sale Price" class="form-control sale_price"/></td>
        <td><input readonly tabindex="3" required type="number" name="subtotal[]" placeholder="" class="form-control subtotal"/></td>
        <td><a href="" class="btn btn-danger cancle">Remove</a></td>
      	</tr>';
      	echo $dom;
      }else if(!$this->db_action->exist('products',array("product_id"=>$product_id))){
      	echo "noProduct";
      }else{
      	echo "empty";
      }

  }

	function sale_history(){
		$this->info['page_title']='Sale History';
		$this->info['active']='dailysale';
		$this->info['sub_active']='salehistory';
		$this->info['confirmation']=null;

		$this->info['all_sale']=$this->db_action->readGroupby('daily_sale',array(),'voucher_no','sale_date','desc');

		if ($this->input->post('view_sale')) {
			$where_array=array();
			foreach ($this->input->post('v_no') as $key => $value) {
				if ($value!=null) {
					$where_array[$key]=$value;
				}
			}

			foreach ($this->input->post('date_from') as $key => $value) {
				if ($value!=null) {
					$where_array[$key.' >= ']=$value;
				}
			}

			foreach ($this->input->post('date_to') as $key => $value) {
				if ($value!=null) {
					$where_array[$key.' <= ']=$value;
				}
			}
			$this->info['all_sale']=$this->db_action->readGroupby('daily_sale',$where_array,'voucher_no');
		}


		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/dailysale/dailysale-nav',$this->info);
		$this->load->view('backend/component/dailysale/salehistory',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

	function payslip_dayli($vno=null){
		$this->info['page_title']='Payslip';
		$this->info['active']='dailysale';
		$this->info['confirmation']=null;

		$where=array(
			'voucher_no'=>$vno
		);
		$this->info['sale_data']=$this->db_action->read('daily_sale',$where);

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/dailysale/payslip',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

}