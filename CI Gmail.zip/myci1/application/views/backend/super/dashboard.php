                        <div class="panel panel-custom">
                             <div class="panel-heading">
                                    <h4>Welcome To Dashboard</h4>
                             </div>
                             <div class="panel-body">
                             <!--Product Quantity review Start here-->
                                    <section class="col-md-6">
                                      <div class="info-item">
                                        <div class="info-header">
                                          <h4>Product Quantity Less than 5 <span class="counter print"><?php echo count($stock_info);?></span></h4>
                                        </div>
                                        <div class="info-body">
                                        <!--pre><?php print_r($user); ?></pre-->
                                        <!--pre><?php print_r($stock_info); ?></pre-->
                                          <table class="table table-striped">
                                            <thead>
                                              <tr class="active">
                                                <th>SL</th>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Quantity</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($stock_info as $stock_key => $stock) {
                                            ?>
                                              <tr>
                                                <td><?php echo $stock_key+1; ?></td>
                                                <td><?php echo $stock->stock_product_id; ?></td>
                                                <td><?php echo $stock->stock_product_name; ?></td>
                                                <td><?php echo $stock->stock_quantity; ?></td>
                                              </tr>
                                              <?php } ?>
                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </section>
                                <!--Product Quantity review End here-->
                                <!--Product Expiration review Start here-->
                                    <section class="col-md-6">
                                      <div class="info-item">
                                        <div class="info-header">
                                          <h4>Product Expiration Date Less than 90 Days <span class="counter print"><?php echo count($stock_expire);?></span></h4>
                                        </div>
                                        <div class="info-body">
                                        <!--pre><?php print_r($stock_expire); ?></pre-->
                                          <table class="table table-striped">
                                            <thead>
                                              <tr class="active">
                                                <th>SL</th>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Expire Date</th>
                                                <th>Remaining Days</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                            <?php foreach ($stock_expire as $expire_key => $expire) {
                                              $product_info=$this->db_action->read("products",array("product_id"=>$expire->stock_product_id));
                                              $remaining_day=strtotime($expire->exp_date)-strtotime(date("Y-m-d"));
                                              $remaining_day=round($remaining_day/86400);
                                            ?>
                                              <tr>
                                                <td><?php echo $expire_key+1; ?></td>
                                                <td><?php echo $expire->stock_product_id; ?></td>
                                                <td><?php echo $expire->stock_product_name; ?></td>
                                                <td><?php echo $expire->exp_date; ?></td>
                                                <td>
                                                <?php 
                                                  if($remaining_day<0){
                                                      echo '<span style="color: red;">'. abs($remaining_day). ' Days Over</span>';
                                                  }
                                                  else{echo $remaining_day." Days";}
                                                   ?>
                                                </td>
                                              </tr>
                                              <?php } ?>
                                            </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </section>
                                <!--Product Expiration review Start here-->
                             </div>
                             <div class="panel-footer"></div>
                        </div>
                    </div>
                </div>
            </div>
      </section>