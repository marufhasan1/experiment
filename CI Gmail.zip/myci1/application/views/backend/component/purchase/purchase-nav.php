                        <div class="page-nav">
                              <a href="<?php echo base_url('backend/purchase');?>" id="new-purchase">New Purchase</a>
                              <a href="<?php echo base_url('backend/purchase/all_purchase');?>" id="all-purchase">All Purchase</a>
                        </div>