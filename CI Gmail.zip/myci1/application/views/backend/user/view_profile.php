<style>
table th{
  width: 20%;
  background: #F5F5F5;
}
.center{
  margin: 5px auto;
  display: block;
  width: 150px;
  border: 5px solid #eee;
  border-radius: 3px;
}
</style>
                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>User Profile</h4>
                             </div>
                             <div class="panel-body">
                                <div class="col-md-8 col-md-offset-2">
                                  <div class="col-sm-12 ">
                                    <img class="center" src="<?php echo site_url($profile_info[0]->image); ?>" alt="">
                                  </div>
                                  <table class="table">
                                  <tr>
                                    <th>Name</th>
                                    <td><?php echo $profile_info[0]->name; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Date of Birth</th>
                                    <td><?php echo $profile_info[0]->birth_date; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Username</th>
                                    <td><?php echo $profile_info[0]->username; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Privilege</th>
                                    <td><?php echo $profile_info[0]->privilege; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Mobile</th>
                                    <td><?php echo $profile_info[0]->mobile; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Email</th>
                                    <td><?php echo $profile_info[0]->email; ?></td>
                                  </tr>
                                </table>
                                </div>
                             </div>
                             <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>