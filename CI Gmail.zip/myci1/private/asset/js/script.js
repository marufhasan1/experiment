$(document).ready(function(){
	/*Top Nav Icon Drop down Start*/
	$('.subnav').on('click',function(){
		$(this).children('ul').slideToggle('',switch_body);
		$(this).siblings('.subnav').children('ul').slideUp('',switch_body);
	});
	function switch_body(){
		$('.content-body').on('click',function(){
			$('.subnav').children('ul').slideUp();
		});
	}
	/*Top Nav Icon Drop down End*/
	/*Aside Sub Item dropdown start*/
		$('.subitem').on('click',function(){
		$(this).children('ul').slideToggle();
		$(this).siblings('.subitem').children('ul').slideUp();
	});
	/*Aside Sub Item dropdown end*/
	/*Aside Navigation Dropdown Start here*/
	$('#show_hide').on('click',function(){
		var condition=$('aside').data('condition');
		if(condition=='show'){
			$('aside').animate({'left':'-200px'});
			$('aside').data('condition','hide');
			$('.content-body').animate({'margin-left':'0'});
			$(this).children('i').removeClass('fa-arrow-left');
			$(this).children('i').addClass('fa-arrow-right');
		}
		else if(condition=='hide'){
			$('aside').animate({'left':'0'});
			$('aside').data('condition','show');
			$('.content-body').animate({'margin-left':'200px'});
			$(this).children('i').removeClass('fa-arrow-right');
			$(this).children('i').addClass('fa-arrow-left');
		}
	});
	/*Aside Navigation Dropdown end here*/
	$('.msg-close').on('click',function(){
		$('.msg_body').fadeOut();
	});

	//Printing page
	    $('#print').click(function() {
          window.print();
        });

    //File browser button start here
    $('.file_browser label').click(function(){
    	$('input[type="file"]').on('change',function(){
    		$(this).siblings("span").html($(this).context.value);
    	});
    });
    //File browser button end here

});

function normal_confirmation(){
	return confirm("This Data Will Delete Permanently....!");
}

function strong_confirmation(){
	var conf=prompt("Write 'CONFIRM' To Make Sure to Delete This Data","");
	if (conf=='CONFIRM'){
		return true;
	}
	return false;
}