                      <style>
                        table tr th{
                          background: #F5F5F5;
                        }

                        .pay-title{
                          text-align: right;
                          border-top: 2px solid #999;
                          font-weight: bold;
                        }
                        .summary{
                          background: #ddd;
                          padding: 0 5px;
                          line-height: 30px;
                          font-weight: bold;
                        }

                        .banner_print{
                          display: none;
                        }

                        @media print {
                          aside,header,.panel-heading{
                            display:  none;
                          }
                          .content-body{
                            margin: 0;
                            border: 0;
                          }
                          .main-content{
                            border: 0;
                            margin: 0;
                          }
                          .body{
                            padding: 0;
                          }
                          .banner_print{
                          display: block;
                          width: 100%;
                          }
                          table.details tr td,
                          table.details tr th,
                          table.details thead tr
                          {
                            border: 1px solid #eee;
                          }
                          table.details{
                            margin-top: 5px;
                          }
                        }
                      </style>                        
                         <div class="panel panel-custom">
                         <?php // echo '<pre>'; print_r($sale_data); echo'</pre>'; ?>
                               <div class="panel-heading">
                                  <h4>Pay Slip</h4>
                                  <span id="print" title="Print"><i class="fa fa-print" aria-hidden="true"></i></span>
                               </div>
                               <div class="panel-body">
                                  <img class="banner_print" src="<?php echo base_url('private/asset/img/banner.png'); ?>" alt=""/>
                                  <p class="pay-title">Pay Slip</p>
                                  <table class="table">
                                    <tr>
                                      <th>Date: </th>
                                      <td><?php echo $sale_data[0]->sale_date; ?></td>
                                    </tr>
                                    <tr>
                                      <th>Voucher No: </th>
                                      <td><?php echo $sale_data[0]->voucher_no; ?></td>
                                    </tr>
                                    <tr>
                                      <th>Customar Name: </th>
                                      <td><?php // echo $sale_data[0]->voucher_no; ?></td>
                                    </tr>
                                  </table>
                                  <p class="summary">Summary</p>
                                  <table class="table details">
                                    <thead>
                                      <tr>
                                        <th>SL</th>
                                        <th>Product Name</th>
                                        <th>Product ID</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Total Price</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                      $total=0;
                                      foreach ($sale_data as $data_key=>$per_data) {
                                      $where=array('product_id'=>$per_data->sale_product_id);
                                      $product_info=$this->db_action->read('products',$where);
                                    ?>
                                      <tr>
                                        <td><?php echo $data_key+1; ?></td>
                                        <td><?php echo $per_data->sale_product_name; ?></td>
                                        <td><?php echo $per_data->sale_product_id; ?></td>
                                        <td><?php echo $per_data->quantity.' '.exist_validation($product_info,"product_unit"); ?></td>
                                        <td><?php echo $per_data->sale_price; ?></td>
                                        <td><?php echo $subtotal=$per_data->sale_price*$per_data->quantity; ?></td>
                                      </tr>
                                    <?php
                                      $total+=$subtotal;
                                     } ?>
                                    <tr>
                                        <th colspan="5" >Total</th>
                                        <td><?php echo $total; ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="3" >Inword</th>
                                        <td colspan="3"><span id="inword"></span></td>
                                    </tr>
                                    </tbody>
                                  </table>
                               </div>

                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script src="<?php echo base_url('private/asset/js/plugins/inwordbn.js');?>"></script>
        <script>
        $(document).ready(function(){
            $('#inword').html(inWordbn(<?php echo $total; ?>)+' টাকা মাত্র');
        });
        </script>