                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>All Supplier</h4>
                             </div>
                             <div class="panel-body">
                              <?php 
                                //print_r($suppliers);
                              ?>
                              <table class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Company Name</th>
                                  <th>Supplier Name</th>
                                  <th>Mobile</th>
                                  <th>Email</th>
                                  <th>Supplier ID</th>
                                  <th>Action</th>
                                </tr>
                                <?php foreach ($suppliers as $key => $supplier) { ?>
                                <tr>
                                  <td><?php echo $key+1; ?></td>
                                  <td><?php echo $supplier->company_name; ?></td>
                                  <td><?php echo $supplier->supplier_name; ?></td>
                                  <td><?php echo $supplier->supplier_mobile; ?></td>
                                  <td><?php echo $supplier->supplier_email; ?></td>
                                  <td><?php echo $supplier->supplier_id; ?></td>
                                  <td>
                                    <a href="<?php echo base_url('backend/supplier/view_supplier');?>?id=<?php echo $supplier->id; ?>" class="btn btn-success">View</a>
                                    <a href="<?php echo base_url('backend/supplier/edit_supplier');?>?id=<?php echo $supplier->id; ?>" class="btn btn-primary">Edit</a>
                                    <a onclick="return(strong_confirmation())" href="?delete_token=<?php echo $supplier->id; ?>" class="btn btn-danger" >Delete</a>
                                  </td>
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>