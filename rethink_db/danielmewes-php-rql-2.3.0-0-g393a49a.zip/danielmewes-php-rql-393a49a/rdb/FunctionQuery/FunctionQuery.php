<?php

namespace r\FunctionQuery;

use r\ValuedQuery\ValuedQuery;

abstract class FunctionQuery extends ValuedQuery
{
}
