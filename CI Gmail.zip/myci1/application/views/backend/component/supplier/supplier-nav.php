                        <div class="page-nav">
                              <a href="<?php echo base_url('backend/supplier');?>" id="add-supplier">Add Supplier</a>
                              <a href="<?php echo base_url('backend/supplier/all_supplier');?>" id="view-supplier">View Supplier</a>
                        </div>