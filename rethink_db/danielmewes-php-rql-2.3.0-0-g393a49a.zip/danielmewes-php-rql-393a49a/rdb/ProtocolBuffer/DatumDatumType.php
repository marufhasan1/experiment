<?php

namespace r\ProtocolBuffer;

class DatumDatumType
{
    const PB_R_ARRAY   = 5;
    const PB_R_BOOL    = 2;
    const PB_R_JSON    = 7;
    const PB_R_NULL    = 1;
    const PB_R_NUM     = 3;
    const PB_R_OBJECT  = 6;
    const PB_R_STR     = 4;
}
