<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<meta src="" type="image/png">
		<title><?php echo $site_title; ?> || <?php echo $page_title; ?></title>
		<!--========================Library Style Sheet========================-->
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/library/font-awesome.css'); ?>" />
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/library/bootstrap.css'); ?>" />
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/library/CustomScrollbar.min.css');?>" />
		<!--========================Library Style Sheet========================-->
		<!--========================Main Style Sheet========================-->
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/login_style.css');?>" />
		<!--========================Main Style Sheet========================-->

		<!--========================Script library========================-->
		<script type="text/javascript" src="<?php echo base_url('private/asset/js/libraries/jquery-1.12.4.min.js');?>"></script>
		<!--========================Script library========================-->
	</head>
	<body>