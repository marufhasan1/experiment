<?php
class Purchase extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Purchase';
		$this->info['active']='purchase';
		$this->info['sub_active']='new-purchase';
		$this->info['confirmation']=null;
		if ($this->input->post('save_product')) {
			$this->form_validation->set_rules('company_name','Company Name','trim|required');
			$this->form_validation->set_rules('voucher_number','Voucher Number','trim|required|is_unique[purchase.voucher_number]');
			if ($this->form_validation->run() == FALSE) {
				$msg_array=array(
				'title'=>"Warinng",
				'message'=>validation_errors()
				);

			$this->session->set_flashdata('confirm', message('warning',$msg_array));
			header("location: ".base_url('/backend/product'));
			}else{
					$product_id	=	$this->input->post('purchase_product_id');
					$quantity	=	$this->input->post('purchase_quantity');
					$price		=	$this->input->post('purchase_price');
					$sale_price	=	$this->input->post('purchase_sale_price');
					$exp_y		=	$this->input->post('exp_y');
					$exp_m		=	$this->input->post('exp_m');
					$exp_d		=	$this->input->post('exp_d');

					$all_data=array();//Array for purchase jeson encoding
				foreach ($this->input->post('purchase_product_name') as $key => $product_name){
					$expire_date = $exp_y[$key]."-".$exp_m[$key]."-".$exp_d[$key];
					//inserting ingo purchase table Start here
					$data=array(
						"purchase_product_id"	=>	$product_id[$key],
						"purchase_quantity"		=>	$quantity[$key],
						"purchase_price"		=>	$price[$key],
						"purchase_sale_price"	=>	$sale_price[$key],
						"purchase_exp_date"		=>	$expire_date
						);
					$all_data[]=$data;
					
					$stock_where=array(
						'stock_product_id'=>$product_id[$key]
						);
					//inserting into purchase table End here

						
					$prev_stock=null;
					//Inserting or Updating into Stock table start here
					//Getting the Product Name start here
					$product_info=$this->db_action->read("products",array("product_id"=>$product_id[$key]));
					$product_name=$product_info[0]->product_name;
					//Getting the Product Name end here

					if ($this->db_action->exist('stock',$stock_where)) {
						$exist_data=$this->db_action->read('stock',$stock_where);
						$prev_stock=$exist_data[0]->stock_quantity;
						$new_data=array(
							'stock_quantity'	=>	$prev_stock+$quantity[$key],
							'stock_date'		=>	date('Y-m-d'),
							'purchase_price'	=>	$price[$key],
							'sale_price'		=>	$sale_price[$key],
							'exp_date'			=>	$expire_date
							);
						$this->db_action->update('stock',$new_data,$stock_where);
					}
					else{
						$new_data=array(
							'stock_product_id'	=>	$product_id[$key],
							'stock_product_name'=>	$product_name,
							'stock_quantity'	=>	$quantity[$key],
							'stock_date'		=>	date('Y-m-d'),
							'purchase_price'	=>	$price[$key],
							'sale_price'		=>	$sale_price[$key],
							'exp_date'			=>	$expire_date
							);
						$this->db_action->add('stock',$new_data);
					}
					$this->info['confirmation']=$this->session->flashdata('confirm');
					//Inserting or Updating into Stock table start here
					
				}
				$data=array(
						"company_name"			=>	$this->input->post("company_name"),
						"voucher_number"		=>	$this->input->post("voucher_number"),
						"date"					=> 	$this->input->post("date"),
						"purchase_data"			=> 	json_encode($all_data)
					);
				$msg_array=array(
						'title'=>"Success",
						'message'=>"Data Successfully Saved"
						);

					$this->session->set_flashdata('confirm', message($this->db_action->add("purchase", $data),$msg_array));
				header("location: ".base_url('/backend/purchase'));
			}
		//print_r($this->input->post('product_name'));
	}
		$this->info['suppliers']=$this->db_action->read('supplier');

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/purchase/purchase-nav',$this->info);
		$this->load->view('backend/component/purchase/purchase',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

	function ajax_get_productInfo(){
		$datalist=array();
		$company= $this->input->post('conpanyName');
		$where=array('company_name'=>$company);
		$products=$this->db_action->read('products',$where);
		foreach ($products as $key => $product) {
			$datalist[]='<option value="'.$product->product_name.'*'.$product->product_id.'">';
		}
		echo json_encode($datalist);
	}
	function ajax_geteach_productInfo(){
		$product= $this->input->post('productId');
		$where=array('product_id'=>$product);
		$products=$this->db_action->read('products',$where);
		echo json_encode($products[0]);
	}

	function all_purchase(){
		$this->info['page_title']='Purchase';
		$this->info['active']='purchase';
		$this->info['sub_active']='all-purchase';
		$this->info['confirmation']=null;

		$this->info['suppliers']=$this->db_action->read('supplier');
		$this->info['all_purchases']=$this->db_action->read('purchase');
		
		if ($this->input->post('view_purchase')) {
			$where_array=array();
			foreach ($this->input->post('field') as $key => $value) {
				if ($value!=null) {
					$where_array[$key]=$value;
				}
				
			}
			$this->info['all_purchases']=$this->db_action->read('purchase',$where_array);
		}

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/purchase/purchase-nav',$this->info);
		$this->load->view('backend/component/purchase/all-purchase',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}


		function purchase_view($id_data=null){
		$this->info['page_title']='Purchase';
		$this->info['active']='purchase';
		$this->info['sub_active']='all-purchase';
		$this->info['confirmation']=null;

		$this->info['purchase_data']=$this->db_action->read('purchase',array("id"=>$id_data));

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/purchase/purchase-nav',$this->info);
		$this->load->view('backend/component/purchase/purchase-view',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}


}