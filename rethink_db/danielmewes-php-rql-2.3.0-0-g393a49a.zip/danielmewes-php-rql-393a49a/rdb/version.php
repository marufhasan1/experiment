<?php

namespace r;

define('PHP_RQL_VERSION', '2.3.0');
