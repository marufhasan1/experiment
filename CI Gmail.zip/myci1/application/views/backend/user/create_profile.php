                        <?php echo $this->session->flashdata('confirm'); ?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Create New Profile</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open_multipart('',$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="name" id="" required> 
                                                </div>
                                          </div>
                                          
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Birth Date</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" id="birth_date" name="birth_date"> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Username <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="username" id="" required> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Password <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="password" name="password" id="" required> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Conform Password <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="password" name="conf_password" id="" required> 
                                                </div>
                                          </div>


                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Privilege <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <select class="form-control" name="privilege" id="">
                                                        <option value="user">User</option>
                                                        <option value="admin">Admin</option>
                                                        <option value="super">Super</option>
                                                      </select>
                                                </div>
                                          </div>

                                          <!--div class="form-group">
                                                <label class="control-label col-md-2" for="">Address</label>
                                                <div class="col-md-6">
                                                      <textarea name="supplier_address" id="" class="form-control"></textarea> 
                                                </div>
                                          </div-->

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Image</label>
                                                <div class="col-md-6">
                                                  <p class="file_browser">
                                                    <input id="image" type="file" name="image"/>
                                                    <label for="image" class="btn btn-default">Browse</label><span></span>
                                                  </p>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Mobile</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="mobile" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Email</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="email" name="email" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <div class="col-md-6 col-sm-offset-2">
                                                      <input class="btn btn-primary" name="add_user" type="submit" value="Submit">       
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer">
                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script type="text/javascript" src="<?php echo base_url('private/asset/js/plugins/zebra_datepicker.js');?>"></script>
        <script type="text/javascript">
          $(document).ready(function(){
            $(document).ready(function() {
                $('input#birth_date').Zebra_DatePicker();
             });
          });
        </script>