jParser library
---------------

These files are "compiled" PHP scripts for production use.
If you wish to inspect the raw source code and/or rebuild these libraries you must download the devel package.

jparser.php
This is the full JavaScript parser required for generating a parse tree.

jtokenizer.php
This is the tokenizer component separated into a smaller library for lighter-weight usage.

For example usage, see ../jparser-examples or point your browser at ../index.html