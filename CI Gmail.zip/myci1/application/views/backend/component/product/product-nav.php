                        <div class="page-nav">
                              <a href="<?php echo base_url('backend/product');?>" id="add-product">Add Product</a>
                              <a href="<?php echo base_url('backend/product/all_product');?>" id="view-product">View Product</a>
                        </div>