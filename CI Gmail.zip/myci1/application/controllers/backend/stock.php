<?php
class Stock extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Purchase';
		$this->info['active']='stock';
		$this->info['sub_active']='new-purchase';
		$this->info['confirmation']=null;
		$this->info['all_stock']=$this->db_action->read('stock');

		if ($this->input->post('view_stock')) {
			$where_array=array();
			foreach ($this->input->post('field') as $key => $value) {
				if ($value!=null) {

					if ($key=="stock_quantity") {
						$where_array[$key." <="]=$value;
					}else{
						$where_array[$key]=$value;
					}
				}

				
			}
			$this->info['all_stock']=$this->db_action->read('stock',$where_array);
		}

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		//$this->load->view('backend/component/stock/purchase-nav',$this->info);
		$this->load->view('backend/component/stock/stock',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
	
}