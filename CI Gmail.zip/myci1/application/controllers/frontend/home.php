<?php
class Home extends Frontend_Controller{
	function __construct(){
		parent::__construct();
	}
	public function index(){
		$this->load->view('frontend/home');
	}
}