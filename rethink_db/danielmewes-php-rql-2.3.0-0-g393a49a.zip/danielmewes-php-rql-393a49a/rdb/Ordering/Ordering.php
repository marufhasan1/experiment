<?php

namespace r\Ordering;

use r\Query;

abstract class Ordering extends Query
{
}
