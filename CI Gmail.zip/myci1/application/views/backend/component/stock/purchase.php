                        <?php echo $this->session->flashdata('confirm');?>
                        <!--This is Dummy Table for Append Data Into Purchase Table-->
                        <table style="display: none;">
                            <tr id="dummy_table" class="per_item">
                              <td><input tabindex="3" list="products_name" autocomplete="off" required type="text" name="purchase_product_name[]" placeholder="Product Name" class="form-control product_name"/></td>
                                <td><input readonly type="text" name="purchase_product_id[]" placeholder="Product ID" class="form-control product_id"/></td>
                                <td><input readonly type="text" placeholder="Brand" class="form-control brand"/></td>
                                <td><input tabindex="3" required type="number" min="0" name="purchase_quantity[]" placeholder="Quantity" class="form-control"/></td>
                                <td><input readonly type="text" placeholder="Unit" class="form-control unit"/></td>
                                <td><input tabindex="3" required type="text" name="purchase_price[]" placeholder="Purchase Price" class="form-control"/></td>
                                <td><input tabindex="3" required type="text" name="purchase_sale_price[]" placeholder="Sale Price" class="form-control"/></td>
                                <td><input tabindex="3" required type="text" name="purchase_exp_date[]" placeholder="yyyy-mm-dd" class="form-control"/></td>
                                <td><a href="" class="btn btn-danger cancle">Remove</a></td>
                            </tr>
                        </table>
                        <!--This is Dummy Table for Append Data Into Purchase Table-->
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>New Purchase</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open('',$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="company_name">Company Name <span class="req">*</span></label>
                                                <div class="col-md-6 no-padding">
                                                    <select tabindex="1" required name="company_name" id="company_name" class="form-control">
                                                      <option value="">--Select Company Name--</option>
                                                      <?php foreach ($suppliers as $key => $supplier) { ?>
                                                      <option value="<?php echo $supplier->company_name?>"><?php echo $supplier->company_name?></option>
                                                      <?php } ?>
                                                    </select>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Voucher Number <span class="req">*</span></label>
                                                <div class="col-md-6 no-padding">
                                                    <input tabindex="1" required type="text" name="voucher_number" placeholder="Voucher Number" class="form-control"/>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Date <span class="req">&nbsp;</span></label>
                                                <div class="col-md-6 no-padding">
                                                    <input tabindex="2" type="text" name="date" class="form-control" value="<?php echo date("Y-m-d");?>">
                                                </div>
                                          </div>

                                          <div class="col-md-12">
                                              <table class="table table-bordered">
                                                <thead>
                                                  <tr class="active">
                                                    <th>Product Name <span class="req">*</span></th>
                                                    <th>Product ID</th>
                                                    <th>Brand</th>
                                                    <th>Quantity <span class="req">*</span></th>
                                                    <th>Unit <span class="req">*</span></th>
                                                    <th>Purchase Price <span class="req">&nbsp;</span></th>
                                                    <th>Sale Price <span class="req">&nbsp;</span></th>
                                                    <th>Exp Date <span class="req">&nbsp;</span></th>
                                                    <th>Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody id="item_data">
                                                  <tr class="per_item">
                                                    <td><input tabindex="3" list="products_name" autocomplete="off" required type="text" name="purchase_product_name[]" placeholder="Product Name" class="form-control product_name"/></td>
                                                    <td><input readonly type="text" name="purchase_product_id[]" placeholder="Product ID" class="form-control product_id"/></td>
                                                    <td><input readonly type="text" placeholder="Brand" class="form-control brand"/></td>
                                                    <td><input tabindex="3" required type="number" min="0" name="purchase_quantity[]" placeholder="Quantity" class="form-control"/></td>
                                                    <td><input readonly type="text" placeholder="Unit" class="form-control unit"/></td>
                                                    <td><input tabindex="3" required type="text" name="purchase_price[]" placeholder="Purchase Price" class="form-control"/></td>
                                                    <td><input tabindex="3" required type="text" name="purchase_sale_price[]" placeholder="Sale Price" class="form-control"/></td>
                                                    <td><input tabindex="3" required type="text" name="purchase_exp_date[]" placeholder="yyyy-mm-dd" class="form-control"/></td>
                                                    <td><a href="" class="btn btn-danger cancle">Remove</a></td>
                                                  </tr>
                                                </tbody>
                                              </table>
                                          </div>


                                          
                                                <div class="col-md-12">
                                                      <input class="btn btn-primary pull-right" name="save_product" type="submit" value="Save">       
                                                      <a class="btn btn-success pull-right" id="add_more">Add More</a>
                                                </div>
                                          
                                    <?php echo form_close(); ?>
                                    <datalist id="products_name"></datalist>
                               </div>
                               <div class="panel-footer">

                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script>
          $(document).ready(function(){
            //Add More Start here
            var sl=1;
            $('#add_more').on('click',function(e){
            $('#item_data').append("<tr>"+$('#dummy_table').html()+"</tr>");
            //console.log(indexOf($(this).parents('tr')));
            console.log($('tbody').find(".sl"));
              e.preventDefault();
            });
            //Add More End here
            //Remove Start here
            $(document).on('click','.cancle',function(ev){
              $(this).parents('tr').remove();
              ev.preventDefault();
            });
            //Remove End here
            //Sending Request by changing Company Name Start here
            $('#company_name').on('change',function(){
              var company=$(this).val();
              $.ajax({
                type:"POST",
                data: {conpanyName:company},
                url:"<?php echo base_url('backend/purchase/ajax_get_productInfo');?>"
                }).success(function(response){
                  var data=JSON.parse(response);
                  $('#products_name').html(data);
                });
            });
            //Sending Request by changing Company Name End here

            //Viewing each data start here
            $(document).on('blur','.product_name',function(){
              var pr_name=$(this).val().split('*');
              var product_id=pr_name[1];
              var this_item=$(this);
              $.ajax({
                type:"POST",
                data: {productId:product_id},
                url:"<?php echo base_url('backend/purchase/ajax_geteach_productInfo');?>"
                }).success(function(response){
                  var product_data=JSON.parse(response);
                  console.log(product_data);
                  this_item.parents('tr').find('input[name="purchase_product_id[]"]').val(product_data.product_id);
                  this_item.parents('tr').find('.unit').val(product_data.product_unit);
                  this_item.parents('tr').find('.brand').val(product_data.product_brand);
                  
                });              
            });
            //Viewing each data end here
          });
        </script>