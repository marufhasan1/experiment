<?php
class Product extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Product';
		$this->info['active']='product';
		$this->info['sub_active']='add-product';
		$this->info['confirmation']=null;
		if ($this->input->post('add_product')) {
			$this->form_validation->set_rules('company_name','Company Name','trim|required');
			$this->form_validation->set_rules('product_name','Product Name','trim|required');
			$this->form_validation->set_rules('product_id','Product ID','trim|is_unique[products.product_id]');
			$this->form_validation->set_rules('product_unit','Product Unit','trim|required');			

			if ($this->form_validation->run() == FALSE) {
				$msg_array=array(
				'title'=>"Warinng",
				'message'=>validation_errors()
				);

			$this->session->set_flashdata('confirm', message('warning',$msg_array));
			header("location: ".base_url('/backend/product'));
			}else{
				$productId=$this->input->post("product_id");
				if ($productId==null || $productId=="") {
					$productId=skip_space($this->input->post("product_name"));
				}
				$data=array(
					"company_name"	=>	$this->input->post("company_name"),
					"product_name"	=>	$this->input->post("product_name"),
					"product_brand"	=>	$this->input->post("product_brand"),
					"product_id"	=>	$productId,
					"product_unit"	=>	$this->input->post("product_unit"),
					"date"			=>	date("Y-m-d")
					);

				$msg_array=array(
					'title'=>"Success",
					'message'=>"Data Successfully Saved"
					);

				$this->session->set_flashdata('confirm', message($this->db_action->add("products", $data),$msg_array));
				//$this->info['confirmation']=$this->session->flashdata('confirm');

				header("location: ".base_url('/backend/product'));
			}
		//print_r($this->input->post('product_name'));
	}
		$this->info['suppliers']=$this->db_action->read('supplier');

		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/product/product-nav',$this->info);
		$this->load->view('backend/component/product/product',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

//-----------------------------------------------------------------------------------------------
//------------------------------------All Product Start here------------------------------------
//-----------------------------------------------------------------------------------------------
	function all_product(){
		$this->info['page_title']='Product';
		$this->info['active']='product';
		$this->info['sub_active']='view-product';
		$this->info['confirmation']=null;

		$this->info['products']=$this->db_action->read('products');

		//--------------------------------------------------------------
		//------------------Delete Data Start here----------------------
		//--------------------------------------------------------------
		if ($this->input->get('delete_token')){
			$where=array(
				'id'=>$this->input->get('delete_token')
				);
			$this->db_action->delete('products',$where);
			redirect(base_url('backend/product/all_product?delete=1'));
			
		}

		$msg_array=array(
			'title'=>"Success",
			'message'=>"Data Successfully Deleted"
		);
		if ($this->input->get('delete')&&$this->input->get('delete')==1) {
			$this->info['confirmation']=message('danger',$msg_array);
		}

		//--------------------------------------------------------------
		//------------------Delete Data End here------------------------
		//--------------------------------------------------------------


		if ($this->input->post('view_product')){
			$where=array(
				'company_name'=>$this->input->post('company_name')
				);
			$this->info['products']=$this->db_action->read('products',$where);
		}
		$this->info['suppliers']=$this->db_action->read('supplier');
		
		
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/product/product-nav',$this->info);
		$this->load->view('backend/component/product/all-product',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
//-----------------------------------------------------------------------------------------------
//-------------------------------------All Product End here-------------------------------------
//-----------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------------
//------------------------------------Edit Product Start here------------------------------------
//------------------------------------------------------------------------------------------------
	function edit_product(){
		$this->info['page_title']='Product';
		$this->info['active']='product';
		$this->info['sub_active']='';
		$this->info['confirmation']=null;

		$where=array(
			'id'=>$this->input->get('id')
			);

		if ($this->input->post('update_product')) {
			$data=array(
					"company_name"=>	$this->input->post("company_name"),
					"product_name"=>	$this->input->post("product_name"),
					"product_brand"=>	$this->input->post("product_brand"),
					"product_id"=>		$this->input->post("product_id"),
					"product_unit"=>	$this->input->post("product_unit"),
					"date"=>			date("Y-m-d")
				);

			$msg_array=array(
				'title'=>"Success",
				'message'=>"Data Successfully Updated"
				);

			$this->session->set_flashdata('confirm', message($this->db_action->update("products", $data,$where),$msg_array));
			header("location: ".base_url('/backend/product/edit_product?id='.$this->input->get('id')));
		}
		$this->info['suppliers']=$this->db_action->read('supplier');
		$this->info['products']=$this->db_action->read('products',$where);
		
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/component/product/product-nav',$this->info);
		$this->load->view('backend/component/product/edit-product',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}
//------------------------------------------------------------------------------------------------
//-------------------------------------Edit Product End here-------------------------------------
//------------------------------------------------------------------------------------------------
}