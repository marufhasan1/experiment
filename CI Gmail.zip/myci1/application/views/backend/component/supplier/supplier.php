                        <?php echo $this->session->flashdata('confirm');?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Add Supplier</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open('',$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Company Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="company_name" id="" required> 
                                                </div>
                                          </div>
                                          
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_name" id="" required> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Mobile No</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_mobile" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Email Address</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="email" name="supplier_email" id=""> 
                                                </div>
                                          </div>


                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier ID <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_id" id="" required> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier Address</label>
                                                <div class="col-md-6">
                                                      <textarea name="supplier_address" id="" class="form-control"></textarea> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Note</label>
                                                <div class="col-md-6">
                                                      <textarea name="supplier_note" id="" class="form-control"></textarea> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <div class="col-md-6 col-sm-offset-2">
                                                      <input class="btn btn-primary" name="add_supplier" type="submit" value="Submit">       
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer">

                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>