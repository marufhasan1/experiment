<?php

namespace r\ProtocolBuffer;

class VersionDummyProtocol
{
    const PB_JSON      = 0x7e6970c7;
    const PB_PROTOBUF  = 0x271ffc41;
}
