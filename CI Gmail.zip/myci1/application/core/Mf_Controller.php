<?php 
	class Mf_Controller extends CI_Controller{
		public $info=array();
		
		function __construct(){
			parent::__construct();
			$this->load->config('Mf_config');
			$this->info['site_title'] = config_item('site_title');

		}

	}

	//------------------------------------------------
	//-----------------For Backend Access-------------
	//------------------------------------------------

		class Backend_Controller extends Mf_Controller{
		function __construct(){
			parent::__construct();
			date_default_timezone_set("Asia/Dhaka");
			$this->info['page_title']='Backend Title';
			$this->load->helper('form');
			$this->load->helper('custom');
			$this->load->library('session');
			$this->loggendin();
			$this->info['user']=$this->session->all_userdata();
			if (isset($this->info['user']['privilege'])) {
				$this->privilege=$this->info['user']['privilege'];
			}
		}



	    public function loggendin(){
	    	if (!$this->session->userdata('logedin')) {
	    		redirect("access/users","refresh");
	    	}
	    }		
	}
	
	//------------------------------------------------
	//-----------------For Frontend Access------------
	//------------------------------------------------
	class Frontend_Controller extends Mf_Controller{
		function __construct(){
			parent::__construct();
			date_default_timezone_set("Asia/Dhaka");
			$this->info['page_title']='Frontend Title';
			$this->load->helper('form');
		}
		
	}
