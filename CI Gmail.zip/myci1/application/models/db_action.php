<?php
	class Db_action extends CI_Model{

		function __construct(){
			parent::__construct();
		}

		function read($table,$where=array(),$field='id',$type='asc'){ //Function for delete data
			$this->db->where($where);
			$this->db->order_by($field,$type);
			$query=$this->db->get($table);
			return $query->result();
		}

		function readGroupby($table,$where=array(),$groupBy,$field='id',$type='asc'){ //Function for delete data
			$this->db->where($where);
			$this->db->group_by($groupBy); 
			$this->db->order_by($field,$type);
			$query=$this->db->get($table);
			return $query->result();
		}

		function add($table,$data=array()){ //Function for Add data
			$query=$this->db->insert($table,$data);
			if($query){
				return "success";
			}
		}

		function update($table,$data=array(),$where=array()){ //Function for Update data
			$this->db->where($where);
			$query=$this->db->update($table,$data);
			if($query){
				return "success";
			}
		}

		function delete($table,$where=array()){ //Function for delete data
			$this->db->where($where);
			if ($this->db->delete($table)) {
				return "danger";
			}
		}
		
		function exist($table,$where=array()){
			$this->db->where($where);
			$query=$this->db->get($table);
			if (count($query->result())>0) {
				return true;
			}
			else{
				return false;
			}
		}

		function sale_product($id){
			$sql="SELECT stock.id,
						 products.product_name,
			 			 products.product_unit,
			 			 stock.stock_product_id,
			 			 stock.stock_quantity,
			 			 stock.purchase_price,
			 			 stock.sale_price,
			 			 stock.exp_date
			 			 FROM products INNER JOIN stock ON products.product_id=stock.stock_product_id where stock.stock_product_id='$id' and stock.stock_quantity>'0'";
			$query=$this->db->query($sql);
			return $query->result();
		}

	}