<style>
table th{
  width: 20%;
  background: #F5F5F5;
}
</style>
                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>Supplier Information</h4>
                             </div>
                             <div class="panel-body">
                                <table class="table">
                                  <tr>
                                    <th class="active">Company Name</th>
                                    <td><?php echo $suppliers[0]->company_name; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Supplier Name</th>
                                    <td><?php echo $suppliers[0]->supplier_name; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Mobile</th>
                                    <td><?php echo $suppliers[0]->supplier_mobile; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Email</th>
                                    <td><?php echo $suppliers[0]->supplier_email; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Supplier ID</th>
                                    <td><?php echo $suppliers[0]->supplier_id; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Supplier Address</th>
                                    <td><?php echo $suppliers[0]->supplier_address; ?></td>
                                  </tr>
                                  <tr>
                                    <th>Note</th>
                                    <td><?php echo $suppliers[0]->supplier_note; ?></td>
                                  </tr>
                                </table>
                             </div>
                             <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>