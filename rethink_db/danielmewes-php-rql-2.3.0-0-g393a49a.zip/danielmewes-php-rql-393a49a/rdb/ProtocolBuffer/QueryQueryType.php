<?php

namespace r\ProtocolBuffer;

class QueryQueryType
{
    const PB_CONTINUE      = 2;
    const PB_NOREPLY_WAIT  = 4;
    const PB_SERVER_INFO   = 5;
    const PB_START         = 1;
    const PB_STOP          = 3;
}
