                        <?php echo $confirmation;?>
                         <div class="panel panel-custom">
                             <div class="panel-heading">
                                <h4>Filter Product</h4>
                             </div>
                             <div class="panel-body">
                              <?php
                                    $attr=array(
                                          'class'=>'form-horizontal'
                                    );
                              echo form_open('',$attr);?>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Company Name <span class="req">&nbsp;</span></label>
                                          <div class="col-md-6">
                                              <select name="field[company_name]" id="" class="form-control">
                                                <option value="">--Select Company Name--</option>
                                                <?php foreach ($suppliers as $key => $supplier) { ?>
                                                <option value="<?php echo $supplier->company_name?>"><?php echo $supplier->company_name?></option>
                                                <?php } ?>
                                              </select>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <label class="control-label col-md-2" for="">Voucher No<span class="req">&nbsp;</span></label>
                                          <div class="col-md-6">
                                              <input type="text" name="field[voucher_number]" class="form-control"/>
                                          </div>
                                    </div>

                                    <div class="form-group">
                                          <div class="col-md-6 col-sm-offset-2">
                                                <input class="btn btn-primary" name="view_purchase" type="submit" value="Show">       
                                          </div>
                                    </div>
                              <?php echo form_close(); ?>
                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php //if($all_purchases!=null){?>
                         <div class="panel panel-custom">
                         <!--pre><?php print_r($all_purchases);?></pre-->
                             <div class="panel-heading">
                                <h4>All Product</h4>
                             </div>
                             <div class="panel-body">
                              <table class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Company Name</th>
                                  <th>Voucher Number</th>
                                  <th>Date</th>
                                  <th>Action</th>
                                </tr>
                                <?php foreach ($all_purchases as $key => $purchases) { ?>
                                <tr>
                                  <td><?php echo $key+1; ?></td>
                                  <td><?php echo $purchases->company_name; ?></td>
                                  <td><?php echo $purchases->voucher_number; ?></td>
                                  <td><?php echo $purchases->date; ?></td>
                                  <td>
                                    <a href="<?php echo base_url('backend/purchase/purchase_view/'.$purchases->id);?>" class="btn btn-primary">View</a>
                                    <a onclick="return(strong_confirmation())" href="?delete_token=<?php // echo $product->id; ?>" class="btn btn-danger" >Delete</a>
                                  </td>
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php // } ?>
                    </div>
                  </div>
            </div>
        </section>