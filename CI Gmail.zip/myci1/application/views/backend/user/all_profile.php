                        <?php echo $this->session->flashdata('confirm');?>
                         <?php //if($all_purchases!=null){?>
                         <div class="panel panel-custom">
                         <!--pre><?php print_r($all_purchases);?></pre-->
                             <div class="panel-heading">
                                <h4>All Profile</h4>
                             </div>
                             <div class="panel-body">
                              <table class="table table-striped table-bordered">
                                <tr class="active">
                                  <th>SL</th>
                                  <th>Image</th>
                                  <th>Name</th>
                                  <th>Username</th>
                                  <th>Mobile</th>
                                  <th>Privilege</th>
                                  <th>Email</th>
                                  <th>Action</th>
                                </tr>
                                <?php foreach ($all_profile as $key => $profile) { ?>
                                <tr>
                                  <td><?php echo $key+1; ?></td>
                                  <td><img src="<?php echo site_url($profile->image); ?>" width="70px" height="70px" alt="Image Not Found"/></td>
                                  <td><?php echo $profile->name; ?></td>
                                  <td><?php echo $profile->username; ?></td>
                                  <td><?php echo $profile->mobile; ?></td>
                                  <td><?php echo $profile->privilege; ?></td>
                                  <td><?php echo $profile->email; ?></td>
                                  <td>
                                    <a href="<?php echo base_url('access/profile/view_profile/'.$profile->username);?>" class="btn btn-primary">View</a>
                                    <a href="<?php echo base_url('access/profile/edit_profile/'.$profile->id);?>" class="btn btn-info">Edit</a>
                                    <a onclick="return(strong_confirmation())" href="<?php echo base_url('access/profile/delete_profile/'.$profile->id);?>" class="btn btn-danger" >Delete</a>
                                  </td>
                                </tr>
                                <?php } ?>
                              </table>

                             </div>
                             <div class="panel-footer"></div>
                         </div>
                         <?php // } ?>
                    </div>
                  </div>
            </div>
        </section>