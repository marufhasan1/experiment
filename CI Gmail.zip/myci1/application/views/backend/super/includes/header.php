<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<meta src="" type="image/png">
		<title><?php echo $site_title; ?> || <?php echo $page_title; ?></title>
		<!--========================Library Style Sheet========================-->
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/library/font-awesome.css'); ?>" />
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/library/bootstrap.css'); ?>" />
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/plugins/zebra_datepicker/default.css'); ?>" />
		<!--========================Library Style Sheet========================-->
		<!--========================Main Style Sheet========================-->
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/style.css');?>" />
		<link rel="stylesheet" href="<?php echo base_url('private/asset/css/responsive.css');?>" />
		<!--========================Main Style Sheet========================-->

		<!--========================Script library========================-->
		<script type="text/javascript" src="<?php echo base_url('private/asset/js/libraries/jquery-1.12.4.min.js');?>"></script>
		<!--========================Script library========================-->
		<style>
			#<?php echo $active ;?>{
				background: #444;
				color: #C5D52B;
			}
			#<?php echo $active ;?>~ul{
				display: block;
			}

			#<?php echo $sub_active ;?>{
				color: #fff;
			}
		</style>
	</head>
	<body>