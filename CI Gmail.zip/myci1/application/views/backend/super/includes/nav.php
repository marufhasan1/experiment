		<header class="container-fluid">
			<div class="row sub-head">
				<div class="top-left">
					<h2>IMS Application</h2>
					<p><?php echo $user['name'];?></p>
				</div>
				<nav class="left-nav">
					<ul>
						<li><a id="show_hide"><i class="fa fa-arrow-left"></i></a></li>
						<li class="subnav" ><a><i class="fa fa-envelope-o"></i></a>
							<ul>
								<li><a href="">Message-1</a></li>
								<li><a href="">Message-2</a></li>
								<li><a href="">Message-3</a></li>
								<li><a href="">View All</a></li>
							</ul>
						</li>
						<li class="subnav" ><a><i class="fa fa-bell-o"></i></a>
							<ul>
								<li><a href="">Notification-1</a></li>
								<li><a href="">Notification-2</a></li>
								<li><a href="">Notification-3</a></li>
								<li><a href="">View All</a></li>
							</ul>
						</li>
					</ul>
				</nav>

				<nav class="right-nav">
					<ul>
						<li class="subnav" ><a><i class="fa fa-power-off"></i></a>
							<ul>
								<li><a href="<?php echo base_url('access/profile/view_profile/'.$user['username']); ?>">Profile</a></li>
								<li><a href="<?php echo base_url('access/profile/all_profile'); ?>">View All Profile</a></li>
								<li><a href="<?php echo base_url('access/profile'); ?>">Create New Profile</a></li>
								<li><a href="<?php echo base_url('access/users/logout'); ?>">Log out</a></li>
							</ul>
						</li>
					</ul>
				</nav>
			</div>
		</header>