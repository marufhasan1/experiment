<?php
class Dashboard extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->loggendin();
	}
	function index(){
		$this->info['page_title']='Dashboard';
		$this->info['active']='dashboard';
		//Retriving Stock quantity start here
		$where=array(
			"stock_quantity <="=> 5
		);
		$this->info['stock_info']=$this->db_action->read('stock',$where);
		//Retriving Stock quantity end here

		//Retriving Stock Expiration start here
		$after90days=new DateTime("+90 Days");
		$after90days=$after90days->format("Y-m-d");
		$where=array(
			"exp_date <=" =>$after90days,
			"stock_quantity >" =>0
		);
		$this->info['stock_expire']=$this->db_action->read('stock',$where);

		//print_r($this->info["user"]);
		//Retriving Stock Expiration start here
		$this->load->view('backend/'.$this->privilege.'/includes/header',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/nav',$this->info);
		$this->load->view('backend/'.$this->privilege.'/includes/aside',$this->info);
		$this->load->view('backend/'.$this->privilege.'/dashboard',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

}