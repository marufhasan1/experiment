<?php

namespace r\Exceptions;

use Exception;

class RqlException extends Exception
{
}
