<?php

namespace r\ProtocolBuffer;

class FrameFrameType
{
    const PB_OPT  = 2;
    const PB_POS  = 1;
}
