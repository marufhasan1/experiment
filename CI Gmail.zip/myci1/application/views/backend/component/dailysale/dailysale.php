                      <style>
                        table tr th{
                          background: #F5F5F5;
                        }
                        #validation_message,.error{
                          display: none;
                          color: #D9534F;
                          margin-right: 5px;
                          font-weight: bold;
                          margin-top: 5px;
                        }
                        .error{
                          background: #bfdeff;
                          padding: 5px 10px;
                          border-radius: 5px;
                        }
                      </style>                        
                        <?php echo $this->session->flashdata('confirm');?>

                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Daily Sale</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal',
                                                'id'=>'add_product_form'
                                          );
                                    echo form_open('',$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Product ID <span class="req">*</span></label>
                                                <div class="col-md-6 no-padding">
                                                    <input tabindex="1" required type="text" autofocus name="product_id" placeholder="Product ID" class="form-control"/>
                                                </div>
                                                <div class="col-md-2">
                                                  <input type="submit" value="Add Product" name="add_product" class="btn btn-primary">
                                                </div>
                                                  <span class="error pull-left" id="prod_alrt"></span>
                                          </div>

                                          <?php echo form_close();
                                          $attr=array(
                                                'id'=>'sale_product_form'
                                          );
                                          echo form_open('',$attr);
                                          ?>

                                          <div class="col-md-12">
                                              <table class="table table-bordered">
                                                <thead>
                                                  <tr class="active">
                                                    <th>Product Name <span class="req">*</span></th>
                                                    <th>Product ID</th>
                                                    <th>Quantity <span class="req">*</span></th>
                                                    <th>Unit <span class="req">*</span></th>
                                                    <th>Sale Price <span class="req">&nbsp;</span></th>
                                                    <th>Sub Total <span class="req">&nbsp;</span></th>
                                                    <th>Action</th>
                                                  </tr>
                                                </thead>
                                                <tbody id="item_data">
                                                </tbody>
                                              </table>
                                          </div>
                                          <div class="col-md-12">
                                                <input class="btn btn-primary pull-right" name="sale_product" type="submit" value="Sale">       
                                                <span id="validation_message" class="pull-right"></span>
                                          </div>
                                          
                                    <?php echo form_close(); ?>
                                    <div class="col-md-6">
                                      <table class="table table-bordered">
                                        <tr>
                                          <th>Voucher No</th>
                                          <td><span><?php echo $voucher_no;?></span></td>
                                        </tr>
                                        <tr>
                                          <th>Total</th>
                                          <td><span id="total"></span></td>
                                        </tr>
                                        <tr>
                                          <th>Inword</th>
                                          <td><span id="inword"></span></td>
                                        </tr>
                                      </table>
                                    </div>
                               </div>
                               <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script src="<?php echo base_url('private/asset/js/plugins/inwordbn.js');?>"></script>
        <script>
          $(document).ready(function(){
            //Remove Start here
            $(document).on('click','.cancle',function(ev){
              $(this).parents('tr').remove();
              ev.preventDefault();
            });
            //Remove End here
            //Focusing
            $(document).dblclick(function(){
              $('input[name="product_id"]').focus();
            });



            //View product start-----------
            $("#add_product_form").on('submit', function(event) {
              event.preventDefault();
              var PID=$('input[name="product_id"]').val();
              var dyn_class="."+PID;

              if ($(dyn_class).length<1) {
                $.ajax({//Sending Request start
                  url: '<?php echo base_url("backend/dailysale/ajax_get_productInfo"); ?>',
                  type: 'POST',
                  data: {pid: PID}
                })
                .done(function(response) {
                  if(response == "noProduct"){
                    product_alert("Unknown Product ID");
                  }
                  else if(response == "empty"){
                    product_alert("Empty Stock");
                  }
                  else{
                    $('#item_data').append(response);
                    row_sum(dyn_class);
                  }
                });//Sending Request end
              }

              else{//Quantity incres if already selected
                var old_val=$(dyn_class+' input[name="quantity[]"]').val();
                $(dyn_class+' input[name="quantity[]"]').val( parseInt(old_val)+1);
                row_sum(dyn_class);
                //console.log(typeof old_val);
              }

              //console.log($("."+PID).length);
              $('input[name="product_id"]').val("");
            });
            //View Product end---------------------

            //Sell Product Start here-----------------------
              $(document).on('submit', '#sale_product_form', function(event) {
                //Validation Start here
                var item_length = $("#item_data").children().length;
                if(item_length<1){
                  event.preventDefault();
                  $("#validation_message").html("Please Select Minimum One Product");
                  $("#validation_message").fadeIn(400, function() {
                    setTimeout(out,1000*2);

                    function out(){
                      $("#validation_message").fadeOut(400);
                    }
                  });
                }
                //Validation End here
              });
            //Sell Product End here-----------------------

            //Counting start here------------------
              $(document).on('change','.quantity',function(){
              var this_item=$(this);
              var price=this_item.parents('tr').find('input[name="sale_price[]"]').val();
              var quantity=this_item.val();
              var sum=price*quantity;
              this_item.parents('tr').find('input[name="subtotal[]"]').val(sum);
              start_counting();
            });


              $(document).on('change','.sale_price',function(){
              var this_item=$(this);
              var price=this_item.val();
              var quantity=this_item.parents('tr').find('input[name="quantity[]"]').val();
              var sum=price*quantity;
              this_item.parents('tr').find('input[name="subtotal[]"]').val(sum);
              start_counting();
            });
            //Counting end here--------------------
          });

            //Function for counting per row on submit
            function row_sum(row_class){
              var price=$(row_class).find('input[name="sale_price[]"]').val();
              var quantity=$(row_class).find('input[name="quantity[]"]').val();
              var sum=price*quantity;
              $(row_class).find('input[name="subtotal[]"]').val(sum);
              start_counting();
            }
            //Function for counting total start
            function total_sum(){
              var all_sub=[];
              $("#item_data .subtotal").each(function(index, el) {
                var each_value=$(el).val()
                all_sub.push(each_value);
              });
              //console.log(all_sub);
              total=0;
                for (var i=0; i<all_sub.length; i++) {
                  total+=parseInt(all_sub[i]);
                }
              $("#total").html(total);
              $("#inword").html(inWordbn(total));
                //console.log(total);
              }
              //Function for counting total end
              function start_counting(){
                setInterval(total_sum,100);
              }

              function product_alert(message){
                  $("#prod_alrt").html(message);
                  $("#prod_alrt").fadeIn(400, function() {
                    setTimeout(out,1000*2);
                  });
                    function out(){
                      $("#prod_alrt").fadeOut(400);
                    }
              }

        </script>
        