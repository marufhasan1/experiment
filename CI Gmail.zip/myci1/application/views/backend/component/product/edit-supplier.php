                        <?php echo $this->session->flashdata('confirm');?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Edit Supplier</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open(base_url('backend/supplier/edit_supplier').'?id='.$this->input->get('id'),$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Company Name</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="company_name" id="" value="<?php echo $suppliers[0]->company_name; ?>"> 
                                                </div>
                                          </div>
                                          
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier Name</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_name" id="" value="<?php echo $suppliers[0]->supplier_name; ?>"> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Mobile No</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_mobile" id="" value="<?php echo $suppliers[0]->supplier_mobile; ?>"> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Email Address</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="email" name="supplier_email" id="" value="<?php echo $suppliers[0]->supplier_email; ?>"> 
                                                </div>
                                          </div>


                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier ID</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" type="text" name="supplier_id" id="" value="<?php echo $suppliers[0]->supplier_id; ?>"> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Supplier Address</label>
                                                <div class="col-md-6">
                                                      <textarea name="supplier_address" id="" class="form-control"><?php echo $suppliers[0]->supplier_address; ?></textarea> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Note</label>
                                                <div class="col-md-6">
                                                      <textarea name="supplier_note" id="" class="form-control"><?php echo $suppliers[0]->supplier_note; ?></textarea> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <div class="col-md-6 col-sm-offset-2">
                                                      <input class="btn btn-success" name="update_supplier" type="submit" value="Update">       
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer">

                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>