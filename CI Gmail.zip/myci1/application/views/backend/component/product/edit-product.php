                        <?php echo $this->session->flashdata('confirm');?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Update Product</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open(base_url('/backend/product/edit_product?id='.$this->input->get('id')),$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Company Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                    <select required name="company_name" id="" class="form-control">
                                                      <option value="">--Select Company Name--</option>
                                                      <?php foreach ($suppliers as $key => $supplier) { ?>
                                                      <option <?php if($products[0]->company_name==$supplier->company_name){echo "selected"; } ?> value="<?php echo $supplier->company_name; ?>"><?php echo $supplier->company_name?></option>
                                                      <?php } ?>
                                                    </select>
                                                </div>
                                          </div>
                                          
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Product Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input value="<?php echo $products[0]->product_name; ?>" required class="form-control" type="text" name="product_name" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Brand</label>
                                                <div class="col-md-6">
                                                      <input value="<?php echo $products[0]->product_brand; ?>" class="form-control" type="text" name="product_brand" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Product ID</label>
                                                <div class="col-md-6">
                                                      <input value="<?php echo $products[0]->product_id; ?>" class="form-control" type="text" name="product_id" id=""> 
                                                </div>
                                          </div>


                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Unit <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                  <select required name="product_unit" id="" class="form-control">
                                                    <option value="">--Select Unit--</option>
                                                    <?php foreach (config_item('units') as $key => $unit) { ?>
                                                    <option <?php if($products[0]->product_unit==$unit){echo "selected"; } ?> value="<?php echo $unit; ?>"><?php echo $unit; ?></option>
                                                    <?php } ?>
                                                  </select>
                                                </div>
                                          </div>
                                          <div class="form-group">
                                                <div class="col-md-6 col-sm-offset-2">
                                                      <input class="btn btn-success" name="update_product" type="submit" value="Update">       
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer">

                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>