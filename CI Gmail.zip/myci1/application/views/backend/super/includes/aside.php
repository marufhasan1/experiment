
		<section class="body container-fluid">
			<div class="row">
				<aside id="aside" data-condition="show">
					<ul class="aside-menu">
						<li><a id="dashboard" href="<?php echo site_url('backend/dashboard');?>"><span class="aside-icon"><i class="fa fa-tachometer" aria-hidden="true"></i></span>Dashboard</a></li>
						<li class="subitem" ><a id="supplier"><span class="aside-icon"><i class="fa fa-briefcase" aria-hidden="true"></i></span>Supplier</a>
							<ul>
								<li><a href="<?php echo site_url('backend/supplier');?>">Add Supplier</a></li>
								<li><a href="<?php echo site_url('backend/supplier/all_supplier');?>">View Supplier</a></li>
							</ul>
						</li>
						<li class="subitem" ><a id="product"><span class="aside-icon"><i class="fa fa-cubes" aria-hidden="true"></i></span>Product</a>
							<ul>
								<li><a href="<?php echo site_url('backend/product');?>">Add Product</a></li>
								<li><a href="<?php echo site_url('backend/product/all_product');?>">View Product</a></li>
							</ul>
						</li>
						<li class="subitem" ><a id="purchase"><span class="aside-icon"><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></span>Purchase</a>
							<ul>
								<li><a href="<?php echo site_url('backend/purchase');?>">New Purchase</a></li>
								<li><a href="<?php echo site_url('backend/purchase/all_purchase');?>">All Purchase</a></li>
							</ul>
						</li>
						<li><a id="dailysale" href="<?php echo site_url('backend/dailysale');?>"><span class="aside-icon"><i class="fa fa-shopping-bag" aria-hidden="true"></i></span>Daily Sale</a></li>
						<li><a id="stock" href="<?php echo site_url('backend/stock');?>"><span class="aside-icon"><i class="fa fa-dropbox" aria-hidden="true"></i></span>Stock</a></li>
					</ul>
				</aside>
                <div class="content-body">
                    <div class="main-content">