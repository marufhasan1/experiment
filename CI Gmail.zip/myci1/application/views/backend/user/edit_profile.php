                        <?php echo $this->session->flashdata('confirm'); ?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Edit Profile</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                          echo form_open_multipart('',$attr);
                                    ?>
                                          <input type="hidden" value="<?php echo $profile_info[0]->image; ?>" name="old_image"/>
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for=""></label>
                                                <div class="col-md-6">
                                                    <div class="col-md-4 col-md-offset-8">
                                                      <div class="row">
                                                        <img class="img-thumbnail" src="<?php echo site_url($profile_info[0]->image); ?>" alt="">
                                                      </div>
                                                    </div>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Name <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" value="<?php echo $profile_info[0]->name; ?>" type="text" name="name" id="" required> 
                                                </div>
                                          </div>
                                          
                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Birth Date</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" value="<?php echo $profile_info[0]->birth_date; ?>" type="text" id="birth_date" name="birth_date"> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Username <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <input class="form-control" value="<?php echo $profile_info[0]->username; ?>"  type="text" name="username" id="" required> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Privilege <span class="req">*</span></label>
                                                <div class="col-md-6">
                                                      <select class="form-control" name="privilege" id="">
                                                        <option <?php if($profile_info[0]->privilege=="user"){ echo "selected"; } ?> value="user">User</option>
                                                        <option <?php if($profile_info[0]->privilege=="admin"){ echo "selected"; } ?> value="admin">Admin</option>
                                                        <option <?php if($profile_info[0]->privilege=="super"){ echo "selected"; } ?> value="super">Super</option>
                                                      </select>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Image</label>
                                                <div class="col-md-6">
                                                  <p class="file_browser">
                                                    <input id="image" type="file" name="image"/>
                                                    <label for="image" class="btn btn-default">Browse</label><span></span>
                                                  </p>
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Mobile</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" value="<?php echo $profile_info[0]->mobile; ?>" type="text" name="mobile" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Email</label>
                                                <div class="col-md-6">
                                                      <input class="form-control" value="<?php echo $profile_info[0]->email; ?>" type="email" name="email" id=""> 
                                                </div>
                                          </div>

                                          <div class="form-group">
                                                <div class="col-md-6 col-sm-offset-2">
                                                      <input class="btn btn-info" name="add_user" type="submit" value="Update">       
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer"></div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script type="text/javascript" src="<?php echo base_url('private/asset/js/plugins/zebra_datepicker.js');?>"></script>
        <script type="text/javascript">
          $(document).ready(function(){
            $(document).ready(function() {
                $('input#birth_date').Zebra_DatePicker();
             });
          });
        </script>