<?php
class Users extends Backend_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('db_action');
		$this->load->library('form_validation');
	}

	function index(){
		$this->info['page_title']='Login';
		$this->info['warning']=null;

		if ($this->loggendin()) {
			redirect("backend/dashboard","refresh");
		}
		//--------------------------------------------------------
		//--------------------Login check Start here--------------
		//--------------------------------------------------------

        $this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]|xss_clean');

		if ($this->input->post('login')) {
			if ($this->form_validation->run()==TRUE) {
				//Login and set session start
				$where=array(
					'username'=>$this->input->post('username'),
					'password'=>$this->hash($this->input->post('password'))
					);

				$user_info=$this->db_action->read('users',$where);
				if ($user_info!=null){
					$data=array(
						'name'=>$user_info[0]->name,
						'username'=>$user_info[0]->username,
						'image'=>$user_info[0]->image,
						'privilege'=>$user_info[0]->privilege,
						'logedin'=>TRUE
						);
					$this->session->set_userdata($data);
					redirect("backend/dashboard","refresh");
					//Login and set session end
				}
				else{
					$this->info['warning']="Invalid Username or Password";
				}
			}
			else{
				$this->info['warning']=validation_errors();
			}
		}

		//--------------------------------------------------------
		//--------------------Login check Start here--------------
		//--------------------------------------------------------
		
		$this->load->view('backend/include/header',$this->info);
		$this->load->view('backend/login',$this->info);
		$this->load->view('backend/include/footer',$this->info);
	}

	function login(){
		if ($this->loggendin()) {
			redirect("backend/dashboard","refresh");
		}else{
			redirect("access/users","refresh");
		}
	}

    public function hash($string) {
        return hash('md5', $string . config_item('encryption_key'));
    }

    public function loggendin(){
    	if ($this->session->userdata('logedin')) {
    		return true;
    	}
    }
    public function logout(){
    	$this->session->sess_destroy();
    	redirect("access/users","refresh");
    }

}