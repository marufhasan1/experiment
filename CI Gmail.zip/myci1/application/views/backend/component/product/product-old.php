                        <?php echo $this->session->flashdata('confirm');?>
                         <div class="panel panel-custom">
                               <div class="panel-heading">
                                     <h4>Add Product</h4>
                               </div>
                               <div class="panel-body">
                                    <?php
                                          $attr=array(
                                                'class'=>'form-horizontal'
                                          );
                                    echo form_open('',$attr);?>

                                          <div class="form-group">
                                                <label class="control-label col-md-2" for="">Company Name <span class="req">*</span></label>
                                                <div class="col-md-8 no-padding">
                                                    <select required name="company_name" id="" class="form-control">
                                                      <option value="">--Select Company Name--</option>
                                                      <?php foreach ($suppliers as $key => $supplier) { ?>
                                                      <option value="<?php echo $supplier->company_name?>"><?php echo $supplier->company_name?></option>
                                                      <?php } ?>
                                                    </select>
                                                </div>
                                          </div>
                                          <div class="col-md-10">
                                              <table class="table">
                                                <tr class="active">
                                                  <th>Product Name <span class="req">*</span></th>
                                                  <th>Brand <span class="req">*</span></th>
                                                  <th>Product ID</th>
                                                  <th>Unit <span class="req">*</span></th>
                                                  <th>Action</th>
                                                </tr>
                                                <tbody>
                                                  <tr class="per_item">
                                                    <td><input required type="text" name="product_name[]" placeholder="Enter The Product Name" class="form-control"/></td>
                                                    <td><input required type="text" name="product_brand[]" placeholder="Enter The Product Brand" class="form-control"/></td>
                                                    <td><input type="text" name="product_id[]" placeholder="Enter The Product ID" class="form-control"/></td>
                                                    <td>
                                                      <select required name="product_unit[]" id="" class="form-control">
                                                        <option value="">--Select Unit--</option>
                                                        <?php foreach (config_item('units') as $key => $unit) { ?>
                                                        <option value="<?php echo $unit; ?>"><?php echo $unit; ?></option>
                                                        <?php } ?>
                                                      </select>
                                                    </td>
                                                    <td><a href="" class="btn btn-danger cancle">Cancel</a></td>
                                                  </tr>
                                                </tbody>
                                              </table>
                                          </div>


                                          <div class="form-group">
                                                <div class="col-md-8 col-sm-offset-2">
                                                      <input class="btn btn-primary pull-right" name="save_product" type="submit" value="Save">       
                                                      <a class="btn btn-success pull-right" id="add_more">Add More</a>
                                                </div>
                                          </div>
                                    <?php echo form_close(); ?>
                               </div>
                               <div class="panel-footer">

                               </div>
                         </div>
                    </div>
                  </div>
            </div>
        </section>
        <script>
          $(document).ready(function(){
            //Add More Start here
            var sl=1;
            $('#add_more').on('click',function(e){
            $('tbody').append($('.per_item').last('tr'));
            $('.sl').html(++sl);
            //console.log(indexOf($(this).parents('tr')));
            console.log($('tbody').find(".sl"));
              e.preventDefault();
            });
            //Add More End here
            //Cancle Start here
            $(document).on('click','.cancle',function(ev){
              $(this).parents('tr').remove();
              ev.preventDefault();
            });
            //Cancle End here
          });
        </script>